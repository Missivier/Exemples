# -*-coding:utf-8 -*-
INCR = 1
ABS = 0
CONTINUE = 2

COORD_BASE = 0
COORD_JOINT = 1
COORD_TOOL = 2

EDIT = 0
LINK = 1


DIFuncType = {0:"none",1:"run",2:"pause",3:"resume",4:"stop", 5:"poweron", 6:"poweroff", 7:"enable", 8:"disable", 9:"reducedmode_LV1", 10:"stopmode",11:'backinitalpos',12:"reducedmode_LV2",13:"clearErr",14:"dragmodeon",15:"dragmodeoff"}
DOFuncType = {0:"none",1:"Idle",2:"pro_suspended",3:"por_running",4:"Error",5:"poweron",6:"enabled",7:"moving",8:"static",9:"startOn",10:"emergency",11:"reducedState",12:"protectiveStop",13:"saftyPos"}

class return_value:
    def __init__(self):
        self.value = {
            # -6:"找不到指定参数",
            -5:"指令参数不正确",
            -4:"指令超时",
            -3:"未登录机器人",
            -2:"请求失败",
            -1:"指令执行失败",
            0:"请求下发成功",
            1:"机器人处于上使能状态",
            2:"机器人下电状态",
            3:"找不到指定参数"
        }

class RobotState:
    def __init__(self):
        self.powered_on = False
        self.enabled = False

class IOState:
    def __init__(self):
        self.do = []
        self.di = []
        self.ai = []
        self.ao = []

class EIPIOState(IOState):
    def __init__(self):
        IOState.__init__(self)
        self.ai_float = []
        self.ao_float = []

class MBSlaveIOState(EIPIOState):
    def __init__(self):
        EIPIOState.__init__(self)
        self.ao_uint=[]
        self.ai_uint = []

class RobotIOState:
    def __init__(self,io = 0):
        self.cabIOState = IOState()
        self.tioState = IOState()
        self.eipIOState = EIPIOState
        self.extIOState = IOState()
        self.mbSlaveIOState = MBSlaveIOState()
        self.pnDevIOState = EIPIOState()
        if io!=0:
            self.cabIOState.do = io['cabIOState']['do']
            self.cabIOState.di = io['cabIOState']['di']
            self.cabIOState.ao = io['cabIOState']['ao']
            self.cabIOState.ai = io['cabIOState']['ai']
            self.tioState.do = io["tioState"]["tio_dout"]
            self.tioState.di = io["tioState"]["tio_din"]
            self.tioState.ao = io["tioState"]["tio_aout"]
            self.tioState.ai = io["tioState"]["tio_ain"]
            self.eipIOState.do = io['eipIOState']['do']
            self.eipIOState.di = io['eipIOState']['di']
            self.eipIOState.ao = io['eipIOState']['ao_int']
            self.eipIOState.ai = io['eipIOState']['ai_int']
            self.eipIOState.ai_float = io['eipIOState']['ai_float']
            self.eipIOState.ao_float = io['eipIOState']['ao_float']
            self.mbSlaveIOState.ao = io['mbSlaveIOState']['ao_int']
            self.mbSlaveIOState.ai = io['mbSlaveIOState']['ai_int']
            self.mbSlaveIOState.do = io['mbSlaveIOState']['do']
            self.mbSlaveIOState.di = io['mbSlaveIOState']['di']
            self.mbSlaveIOState.ai_float = io['mbSlaveIOState']['ai_float']
            self.mbSlaveIOState.ao_float = io['mbSlaveIOState']['ao_float']
            self.mbSlaveIOState.ai_uint = io['mbSlaveIOState']['ai_uint']
            self.mbSlaveIOState.ao_uint = io['mbSlaveIOState']['ao_uint']
            self.pnDevIOState.do = io['pnDevIOState']['do']
            self.pnDevIOState.di = io['pnDevIOState']['di']
            self.pnDevIOState.ao = io['pnDevIOState']['ao_int']
            self.pnDevIOState.ai = io['pnDevIOState']['ai_int']
            self.pnDevIOState.ai_float = io['pnDevIOState']['ai_float']
            self.pnDevIOState.ao_float = io['pnDevIOState']['ao_float']
            try:
                self.extIOState.ao = io['extIOState']['extio_aout']
                self.extIOState.ai = io['extIOState']['extio_ain']
                self.extIOState.do = io['extIOState']['extio_dout']
                self.extIOState.di = io['extIOState']['extio_din']
            except:
                pass

class HeartBeat:
    def __init__(self):
        self.dout = 0
        self.robot_in_drag = 0
        self.servo_upGrade_percentage_total = 0
        self.basicIoType = 0
        self.robot_on_slimit = 0
        self.eip_state = 0
        self.tio_ain = 0
        self.extio_aout = 0
        self.extio_state = 0
        self.currUsrFrameId = 0
        self.robot_powered_on = 0
        self.profinetState = 0
        self.drag_near_limit = 0
        self.extio_dout = 0
        self.prog_stat = 0
        self.isCollectingDiagData = 0
        self.joint_position = 0
        self.scb_stick_locked = 0
        self.errstring = 0
        self.position_segTarget = 0
        self.relay_io = 0
        self.tio_din = 0
        self.tio_aout = 0
        self.aout = 0
        self.emergency_stop = 0
        self.extio_ain = 0
        self.tio_dout = 0
        self.steppingWait = 0
        self.torque_sensor_state = 0
        self.extio_din = 0
        self.reduce_mode = 0
        self.upgFirmware = 0
        self.errtype = 0
        self.servo_upGrade_percentage_axis = 0
        self.servoDebugEnable = 0
        self.din = 0
        self.protective_stop = 0
        self.admittance_enabled = 0
        self.isSamplingTrajPoint = 0
        self.currToolId = 0
        self.robot_enabled = 0
        self.tio_key_state = 0
        self.errcode = 0
        self.cartesian_position = 0
        self.ain = 0

    def assignment(self,data):           
        self.dout = data["dout"]
        self.robot_in_drag = data["robot_in_drag"]
        self.servo_upGrade_percentage_total = data["servo_upGrade_percentage_total"]
        self.basicIoType = data["basicIoType"]
        self.robot_on_slimit = data["robot_on_slimit"]
        self.eip_state = data["eip_state"]
        self.tio_ain = data["tio_ain"]
        self.extio_aout = data["extio_aout"]
        self.extio_state = data["extio_state"]
        self.currUsrFrameId = data["currUsrFrameId"]
        self.robot_powered_on = data["robot_powered_on"]
        self.profinetState = data["profinetState"]
        self.drag_near_limit = data["drag_near_limit"]
        self.extio_dout = data["extio_dout"]
        self.prog_stat = data["prog_stat"]
        self.isCollectingDiagData = data["isCollectingDiagData"]
        self.joint_position = data["joint_position"]
        self.scb_stick_locked = data["scb_stick_locked"]
        self.errstring = data["errstring"]
        # self.position_segTarget = data["position_segTarget"]
        self.relay_io = data["relay_io"]
        self.tio_din = data["tio_din"]
        self.tio_aout = data["tio_aout"]
        self.aout = data["aout"]
        self.emergency_stop = data["emergency_stop"]
        self.extio_ain = data["extio_ain"]
        self.tio_dout = data["tio_dout"]
        self.steppingWait = data["steppingWait"]
        self.torque_sensor_state = data["torque_sensor_state"]
        self.extio_din = data["extio_din"]
        self.reduce_mode = data["reduce_mode"]
        self.upgFirmware = data["upgFirmware"]
        self.errtype = data["errtype"]
        self.servo_upGrade_percentage_axis = data["servo_upGrade_percentage_axis"]
        self.servoDebugEnable = data["servoDebugEnable"]
        self.din = data["din"]
        self.protective_stop = data["protective_stop"]
        self.admittance_enabled = data["admittance_enabled"]
        self.isSamplingTrajPoint = data["isSamplingTrajPoint"]
        self.currToolId = data["currToolId"]
        self.robot_enabled = data["robot_enabled"]
        self.tio_key_state = data["tio_key_state"]
        self.errcode = data["errcode"]
        self.cartesian_position = data["cartesian_position"]
        self.ain = data["ain"]

class ToolData:
    def __init__(self,data = 0):
        self.name = ''
        self.id = 0
        self.x = 0
        self.y = 0
        self.z = 0
        self.rx = 0
        self.ry = 0
        self.rz = 0
        if data != 0:
            self.name = data['name']
            self.id = data['id']
            self.x = data['tooloffset']['x']
            self.y = data['tooloffset']['y']
            self.z = data['tooloffset']['z']
            self.rx = data['tooloffset']['a']
            self.ry = data['tooloffset']['b']
            self.rz = data['tooloffset']['c']

class TCP_IP_Comm:
    def __init__(self):
        self.ipaddr = "" #//ip地址
        self.port =  0 #//端口号
        self.slaveId = 1

    def assignment(self,info):
        self.ipaddr = info['ipaddr']
        self.port = info['port']
        self.slaveId = info['slaveId']

class SignalParameters:
    def __init__(self):
        self.pinnum = 0 #//引数量脚
        self.startaddr = 0

    def assignment(self,info):
        self.pinnum = info['pinnum']
        self.startaddr = info['startaddr']

class EXTIOsetup:
    def __init__(self):
        self.doSetup = SignalParameters() #//do设置
        self.aoSetup = SignalParameters()#//模拟输出
        self.diSetup = SignalParameters()
        self.aiSetup = SignalParameters()

    def assignment(self,info):
        self.doSetup.assignment(info['doSetup'])
        self.aoSetup.assignment(info['aoSetup'])
        self.diSetup.assignment(info['diSetup'])
        self.aiSetup.assignment(info['aiSetup'])      

class EXIOConfig:
    def __init__(self,info = {}):
        self.intid = 0
        self.modName = ''
        self.tcpComm = TCP_IP_Comm()
        self.extiosetup = EXTIOsetup()
        self.type = 1
        self.ExtIOModInfo = ''
        try:
            self.modName = info['modName']
            self.tcpComm.assignment(info['tcpComm'])
            self.type = info['type']
            self.extiosetup.assignment(info)
            self.ExtIOModInfo = info['ExtIOModInfo']
        except:
            pass

    def add_config(self):
        res = {
            "extiosetup": {
            "modName": self.modName, #//modbus名字
            "tcpComm": {
            "ipaddr": self.tcpComm.ipaddr, #//ip地址
            "port": self.tcpComm.port, #//端口号
            "slaveId": self.tcpComm.slaveId #//设备号
            }, #//tcp协议端口
            "doSetup": {
            "pinnum": self.extiosetup.doSetup.pinnum, #//引数量脚
            "startaddr": self.extiosetup.doSetup.startaddr #//起始偏移地址
            }, #//do设置
            "aoSetup": {
            "pinnum": self.extiosetup.aoSetup.pinnum, #//引数量脚
            "startaddr": self.extiosetup.aoSetup.startaddr #//起始偏移地址
            }, #//模拟输出
            "diSetup": {
            "pinnum": self.extiosetup.diSetup.pinnum, #//引数量脚
            "startaddr": self.extiosetup.diSetup.startaddr #//起始偏移地址
            }, #//数字输入
            "type": self.type, #//连接类型
            "aiSetup": {
            "pinnum": self.extiosetup.aiSetup.pinnum, #//引数量脚
            "startaddr": self.extiosetup.aiSetup.startaddr #//起始偏移地址
            } #//模拟输入
            } #//extio配置
            }

        return res

    def modify_config(self):
        res = {
            "intid": self.intid,
            "extiosetup": {
            "modName": self.modName, #//modbus名字
            "tcpComm": {
            "ipaddr": self.tcpComm.ipaddr, #//ip地址
            "port": self.tcpComm.port, #//端口号
            "slaveId": self.tcpComm.slaveId #//设备号
            }, #//tcp协议端口
            "doSetup": {
            "pinnum": self.extiosetup.doSetup.pinnum, #//引数量脚
            "startaddr": self.extiosetup.doSetup.startaddr #//起始偏移地址
            }, #//do设置
            "aoSetup": {
            "pinnum": self.extiosetup.aoSetup.pinnum, #//引数量脚
            "startaddr": self.extiosetup.aoSetup.startaddr #//起始偏移地址
            }, #//模拟输出
            "diSetup": {
            "pinnum": self.extiosetup.diSetup.pinnum, #//引数量脚
            "startaddr": self.extiosetup.diSetup.startaddr #//起始偏移地址
            }, #//数字输入
            "type": self.type, #//连接类型
            "aiSetup": {
            "pinnum": self.extiosetup.aiSetup.pinnum, #//引数量脚
            "startaddr": self.extiosetup.aiSetup.startaddr #//起始偏移地址
            } #//模拟输入
            } #//extio配置
            }

def DIFunction_assignment(info):
    data = {}
    for di in info:
        data[DIFuncType[di['action']]] = [di['type'],di['id']]
    return data

def DOFunction_assignment(info):
    data = {}
    for do in info:
        try:
            data[DOFuncType[do['action']]] = [do['type'],do['id']]
        except: 
            do
    return data
