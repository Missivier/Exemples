# -*-coding:utf-8 -*-
from time import sleep,time
import requests
import json
from .jktpye import *

__all__ = ['JAKAREQUESTS']

class JAKAREQUESTS:
    '''10005端口请求工具'''
    def __init__(self,ip,debug =False):
        self.__login_flag = False
        self.robot_ip = ip
        self.err_code = 0
        self.debug = debug
        pass

    def __send_requests(self,url,body):
        '''post请求函数'''
        if 'dict' in str(type(body)):
            body = json.dumps(body)
        try:
            r = requests.post(url,data=body,headers = {"Content-Type": "application/json;charset=utf8"})
            r.encoding = 'utf-8'
            if self.debug:
                print("debug_info:",r.status_code,';',r.text)
            return (r.status_code,r.text)
        except:
            return (-2,{})

    def __send2robot(self,func,body):
        '''向机器人发送POST请求函数'''
        url = "http://%s:10005/robot/v1.0/%s"%(self.robot_ip,func)
        ret = self.__send_requests(url,body)
        status_code = ret[0]
        if status_code == 200:
            data = json.loads(ret[1])
            if data['error_code'] == 0:
                return (0,data)
            else:
                res = "addon:error_code:%s;errormsg:%s"%(str(data["error_code"]) , data["errormsg"])
                errorType = {
                    "Invalid arguments":-5
                }
                try:
                    return (errorType[data["errormsg"]],res)
                except:
                    return (-1,res)
        else:
            return (-2, )

    def __get_message(self,func,body,back_info = []):   
        '''请求发送的逻辑判断和提取返回信息'''
        if self.__login_flag:
            ret = self.__send2robot(func,body)
            if ret[0] == 0:
                data = ret[1]
                try:
                    if back_info != []:
                        for key in back_info:
                            data = data[key]
                    return (0,data)
                except:
                    print('back_info error!')
            return ret
        else:
            return (-3, )

    def __return_standard(self,data,index = 0,info = []):
        '''生成具体请求的返回数据'''
        if data[0] == 0:
            if index != 0:
                res = data[index]
                if info != []:
                    for i in info:
                        res = res[i]
                return (res)
            else:
                return (0,data[0])
        else:
            return data
    
    def trnaslate(self,value):
        '''根据具体请求的返回值，给出其对应的含义'''
        returnvalue = return_value()
        if len(value) == 1:
            print(returnvalue.value[0])
            return returnvalue.value[value]
        else:
            print(returnvalue.value[value[0]])
            return returnvalue.value[value[0]]

    def login(self,username,password):
        '''登录机器人方法'''
        body = {
            "loginfo": {
            "username": username, #"jakazu7admin", #//用户名
            "password": password #"jakazuadmin" #//密码
            } #//登陆信息
            }
        ret = self.__send2robot('login',body)
        if ret[0] == 0:
            self.__login_flag = True
            return 0
        else:
            return ret[0]

    def heart_beat(self):
        '''获取机器人心跳'''
        info = ['data','heartbeat']
        data = self.__get_message('heart_beat',{},info)
        res = self.__return_standard(data,1)
        try:
            heartbeat = HeartBeat()
            heartbeat.assignment(res)
            return heartbeat
        
        except:
            self.err_code = res[0]
            return (self.err_code,res[1])

    def get_error(self):
        '''获取错误信息'''
        data = self.heart_beat()
        try:
            return (data.errtype,data.errcode,data.errstring)
        except:
            return (self.err_code,)
    
    def clear_error(self):
        '''清除错误'''
        data = self.__get_message('clear_error',{})
        res = self.__return_standard(data)
        return res

    def get_program_state(self):
        '''获取程序状态，0为不运行，1为正常执行，2为暂停'''
        data = self.heart_beat()
        try:
            return data.prog_stat
        except:
            return (self.err_code,)

    def get_robot_state(self):
        '''获取机器人状态，可传入RobotState()对象，直接修改对象中的变量；
        若不传入对象，返回值中会返回机器人的状态码：1下电，2上电，3下使能，4上使能'''
        data = self.heart_beat()
        state = RobotState()
        try:
            state.powered_on = data.robot_powered_on
            state.enabled = data.robot_enabled
            return state
        except:
            return (self.err_code,)

    def get_dhcp_or_static_ip(self):
        '''未知'''
        data = self.__get_message('get_dhcp_or_static_ip',{})
        res = self.__return_standard(data)
        return res

    def __state_change(self,expstate):
        '''切换机器人状态'''
        body = {
            "statechangereq": {
            "expstate": expstate #//状态类型，1：下电，2：上电，3下使能，4上使能（需在2状态下）
            }
            }
        data = self.__get_message('state_change',body)
        res = self.__return_standard(data)
        return res

    def __state_timeout(self,judge):
        judgement = {
            'poweron':not self.get_robot_state().powered_on,
            'poweroff':self.get_robot_state().powered_on,
            'enable':not self.get_robot_state().enabled,
            'disable':self.get_robot_state().enabled
        }
        start_time = time()
        while judgement[judge]:
            sleep(0.1)
            end_time = time()
            if end_time - start_time > 10:
                return False
        return True

    def power_on(self):
        '''机器人上电'''
        data = self.get_robot_state()
        try:
            if not data.powered_on:
                ret = self.__state_change(2)
                if self.__state_timeout('poweron'):
                    res = self.__return_standard(ret)
                    return res
                else:
                    return (-4,)
            else:
                return (0,)
        except:
            return (self.err_code,)

    def power_off(self):
        '''机器人下电'''
        data = self.get_robot_state()
        try:
            if data.enabled:
                return (1,)
            else:
                ret = self.__state_change(1)
                if self.__state_timeout('poweroff'):
                    res = self.__return_standard(ret)
                    return res
        except:
            return (self.err_code,)
        
    def enabled_robot(self):
        '''机器人上使能'''
        data = self.get_robot_state()
        try:
            if data.powered_on:
                ret = self.__state_change(4)
                if self.__state_timeout('enable'):
                    res = self.__return_standard(ret)
                    return res
                else:
                    return (-4,)
            else:
                return (2,)
        except:
            return (self.err_code,)

    def disabled_robot(self):
        '''机器人下使能'''
        data = self.get_robot_state()
        try:
            if data.enabled:
                ret = self.__state_change(3)
                if self.__state_timeout('disable'):
                    res = self.__return_standard(ret)
                    return res
                else:
                    return (-4,)
            else:
                return (0,)
        except:
            return (self.err_code,)

    def get_io_state(self,iostate= 0):
        '''获取IO状态'''
        info = ['data','ioState']
        body = {
            "ioState": {
            "ioType": -1 #//-1显示所有io类型
            }
            }
        data = self.__get_message('get_io_state',body,info)
        res = self.__return_standard(data,1)
        
        iostate = RobotIOState(res)
        return iostate
    
    def set_dout(self,iotype,index,state):
        '''设置do状态'''
        body = {
            "dout": {
            "type": iotype, #//DO类型
            "index": index, #//DO序号
            "value": state #//DO值
            }
            }

        data = self.__get_message('set_dout',body)
        res = self.__return_standard(data)
        return res

    def set_aout(self,iotype,index,state):
        '''设置ao状态'''
        body = {
            "aout": {
            "type": iotype, #//DO类型
            "index": index, #//DO序号
            "value": state #//DO值
            }
            }

        data = self.__get_message('set_aout',body)
        res = self.__return_standard(data)
        return res

    def __get_mutitool_offest(self):
        data = self.__get_message('get_mutitool_offset',{})
        res = self.__return_standard(data,1,['data','mutitooloffset'])
        return res

    def get_current_tool(self):
        '''获取当前TCP信息，返回值类型 ToolData()'''
        data = self.__get_mutitool_offest()
        current = data[1]['currentId']
        for tooldata in data[1]['toolInfo']:
            if tooldata['id'] == current:
                tool = ToolData(tooldata)
                return tool

    def get_tool_data(self,id):
        '''获取指定id的TCP信息''' 
        data = self.__get_mutitool_offest() 
        try:
            for tooldata in data[1]['toolInfo']:
                if tooldata['id'] == id:
                    tool = ToolData(tooldata)
                    return tool
            if id > 10:
                return (-5,)
        except:
            return (data[0],)

    def set_tool(self,id,data,name):
        '''设置TCP，传入被设置TCP的id和其对应的参数，角度单位为°'''
        body = {
                "mutitooloffset": {
                "toolInfo": [
                {"id": id, #//tcp坐标系id
                 "tooloffset": {
                "a": data[3], #//rx
                "c": data[5], #//rz
                "b": data[4], #//ry
                "y": data[1],# //y
                "x": data[0], #//x
                "z": data[2] #//z
                },
                "name": name #//tcp坐标系名
                }
                ]
                }
                }
        data = self.__get_message('set_mutitool_offset',body)
        res = self.__return_standard(data,0,[])
        return res

    def switch_tool_id(self,id):
        '''切换当前的TCP'''
        body = {"intid": id}
        data = self.__get_message('set_current_tool_id',body)
        res = self.__return_standard(data,0,[])
        return res

    def get_extio_list(self):
        '''获取拓展IO名称列表'''
        body = {}
        data = self.__get_message('get_extio_brief_info',body)
        res = self.__return_standard(data,1,['data','extioinfo','modname'])
        return res

    def get_extio_config(self,id):
        '''获取指定拓展IO参数，可传入被查询拓展IO的id或名称'''
        if 'int' in str(id.__class__):
            body = {"intid": id}
            data = self.__get_message('get_extio_mod_config',body)
            res = self.__return_standard(data,1,['data','extioconfig'])
            return res
        if 'str' in str(id.__class__):
            try:
                intid = self.get_extio_list().index(id)
                return self.get_extio_config(intid)
            except:
                return(-5,)
    
    def set_extio_mode(self,extio_mode):
        '''切换拓展IO状态，0为编辑模式，1为通讯模式'''
        if extio_mode in [0,1]:
            state = self.get_robot_state()
            if not state.enabled:
                body = {
                    "intid": extio_mode #//模式类型
                    }
                data = self.__get_message('set_extio_mode',body)
                res = self.__return_standard(data,0,[])
                return res
            else:
                return (1,)
        return (-5)

    def add_extio(self,setup):
        '''添加拓展IO，传入EXIOConfig()对象 '''
        backcode = self.set_extio_mode(EDIT)
        if backcode == (0,0):
            try:
                body = setup.add_config()
                data = self.__get_message('add_extio_mod',body)
                res = self.__return_standard(data,0,[])
                return res
            except:
                return (-5,)
        else:
            return backcode

    def delete_extio(self,id):
        '''删除指定拓展IO参数，可传入被查询拓展IO的id或名称'''
        backcode = self.set_extio_mode(EDIT)
        if backcode == (0,0):
            if 'int' in str(id.__class__):
                body = {"intid": id}
                data = self.__get_message('delete_extio_mod',body)
                res = self.__return_standard(data,1,['data','extioconfig'])
                return res
            if 'str' in str(id.__class__):
                try:
                    intid = self.get_extio_list().index(id)
                    return self.delete_extio(intid)
                except:
                    return(-5,)
        else:
            return backcode

    def modify_extio_config(self,setup):
        '''修改指定拓展IO，传入EXIOConfig()对象 '''
        backcode = self.set_extio_mode(EDIT)
        if backcode == (0,0):
            try:
                body = setup.modify_config()
                data = self.__get_message('modify_extio_mod',body)
                res = self.__return_standard(data,0,[])
                return res
            except:
                return (-5,)
        else:
            return backcode

    def get_current_program(self):
        '''获取被加载的程序名称'''
        data = self.__get_message('get_current_program',{})
        res = self.__return_standard(data,1,['data','str'])
        return res

    def load_program(self,pro_name):
        '''加载程序，传入程序名，如"新建编程"'''
        body = {
                "str": 'program/'+pro_name+'/'+pro_name+'.jks' #//程序名.jks
                }
        data = self.__get_message('load_program',body)
        res = self.__return_standard(data,0,[])
        return res

    def run_porgram(self,pro_name):
        '''运行程序，传入程序名，如"新建编程"'''
        body = {
            "str": 'program/'+pro_name+'/'+pro_name+'.jks' #//程序名.jks
            }
        data = self.__get_message('run_program',body)
        res = self.__return_standard(data,0,[])
        return res
    
    def get_current_line(self):
        '''获取目前正在执行的脚本行数'''
        data = self.__get_message('get_current_line',{})
        res = self.__return_standard(data,1,['data','intid'])
        return res

    def resume_program(self):
        '''继续执行程序'''
        data = self.__get_message('resume_program',{})
        res = self.__return_standard(data,0,[])
        return res

    def pause_program(self):
        '''暂停程序'''
        data = self.__get_message('pause_program',{})
        res = self.__return_standard(data,0,[])
        return res

    def jog(self,jogmode,jogcoord,aix,vel,pos):
        '''jog运动
jogmode:jog运动模式，0:增量，1:绝对，2：连续
jogcoord:jog运动坐标，0:关节，2：世界，3：工具
aix:关节号[0,5]
vel:速度 单位°/s  or mm/s
pos:位移量，单位° or mm'''
        body = {
            "jogreq": {
            "jogmode": jogmode,
            "jogcoord": jogcoord,
            "ajnum": aix,
            "jogvel": vel,
            "poscmd": pos
            }
            }
        data = self.__get_message('jog',body)
        res = self.__return_standard(data,0,[])
        return res

    def jog_stop(self,aix):
        '''终止jog运动
aix：关节号[0,5]'''
        if aix in [0,1,2,3,4,5]:
            body = {
            "intid": aix
            }
            data = self.__get_message('jog_stop',body)
            res = self.__return_standard(data,0,[])
            return res
        else:
            return (-5,)

    def joint_move(self,jointvalue,vel):
        '''关节运动
jointvalue: 关节空间位置目标点,单位°
vel：速度单位°/s'''
        body = {
        "movjreq": {
        "jointpos": {
        "joint1": jointvalue[0],
        "joint2": jointvalue[1],
        "joint3": jointvalue[2],
        "joint4": jointvalue[3],
        "joint5": jointvalue[4],
        "joint6": jointvalue[5]
        },
        "velocity": vel 
        }
        }
        data = self.__get_message('movj',body)
        res = self.__return_standard(data,0,[])
        return res

    def linear_move(self,position,vel):
        '''空间运动
position: 关节空间位置目标点,单位mm
vel：速度单位°/s'''
        body = {
            "movlreq": {
            "cartpos": {
            "x": position[0], 
            "y": position[1],
            "z": position[2],
            "a": position[3],
            "b": position[4],
            "c": position[5]
            },
            "velocity": vel
            }
            }
        data = self.__get_message('movl',body)
        res = self.__return_standard(data,0,[])
        return res

    def set_di_func(self,ioType,ioIndex,function):
        '''设置DI功能IO
ioType：io类型: 0 标准IO，1 工具IO，2 Modbus 主站IO，3继电器IO， 4 Modbus从站IO， 5 Profinet设备IO， 6 EIP Adapter IO
ioIndex：io地址，从0开始
function：0:none,1:run,2:pause,3:resume,4:stop, 5:poweron, 6:poweroff, 7:servoon, 8:servooff, 9:reducedmode, 10:stopmode'''
        body = {
            "diset": {
            "type": ioType, 
            "id": ioIndex,
            "action": function
            }
            }
        data = self.__get_message('set_di_func',body)
        res = self.__return_standard(data,0,[])
        return res
 
    def get_di_func(self):
        '''获取DI功能IO'''
        data = self.__get_message('get_di_func',{})
        res = self.__return_standard(data,1,["data","getdifunc","disets"])
        return DIFunction_assignment(res)

    def set_do_func(self,ioType,ioIndex,function):
        '''设置DO功能IO
ioType：io类型: 0 标准IO，1 工具IO，2 Modbus 主站IO，3继电器IO 4 Modbus从站IO 5Profinet设备IO 6 EIP Adapter IO
ioIndex：io地址，从0开始
function:0 无，1 空闲，2程序暂停，3程序运行...'''
        body = {
            "doset": {
            "type": 0, 
            "id": 2,
            "action": 3 
            }
            }
        data = self.__get_message('set_do_func',body)
        res = self.__return_standard(data,0,[])
        return res

    def get_do_func(self):
        '''获取DO功能IO'''
        data = self.__get_message('get_do_func',{})
        res = self.__return_standard(data,1,["data","getdofunc","dosets"])
        return DOFunction_assignment(res)

    def modify_sysvar(self,value, var):
        '''修改指定名称或id的系统变量名的值'''
        sysvar = self.get_sysvar_list(var)
        try:
            sysvar["value"] = value
        except:
            return sysvar
        body = {
            "variable": sysvar
        }
        data = self.__get_message('modify_user_defined_variable',body)
        res = self.__return_standard(data,0,[])
        return res

    def rename_sysvar(self,var_id,name):
        '''修改指定id的系统变量的名字'''
        sysvar = self.get_sysvar_list(var_id)
        try:
            sysvar["alias"] = name
        except:
            return sysvar
        body = {
            "variable": sysvar
        }
        data = self.__get_message('modify_user_defined_variable',body)
        res = self.__return_standard(data,0,[])
        return res
     
    def add_sysvar(self,name,value):
        '''添加系统变量'''
        body = {
                "variable": {
                "alias": name, #//别名
                "value": value #//值
                }
                }

        data = self.__get_message('add_user_defined_variable',body)
        res = self.__return_standard(data,0,[])
        return res

    def get_sysvar_list(self,var = ''):
        data = self.__get_message('query_user_defined_variable',{})
        res = self.__return_standard(data,1,["data","uservariable","variable"])
        if var != '':
            for i in res:
                if i['id'] == var or i['alias'] == var:
                    return i
            return (3,)
        return res

    def sysvar_exist(self,var):
        '''判断系统变量是否存在'''
        try:
            ret = self.get_sysvar_list(var)
            if ret[0] == 3:
                return False
            else:
                return ret
        except:
            return True

    def delete_sysvar(self,var):
        '''删除指定系统变量'''
        sysvar = self.get_sysvar_list(var)
        body = {
                "deleteudv": {
                "id": [sysvar['id']] #//要删除的ID的数组
                }
                }
        data = self.__get_message('delete_user_defined_variable',body)
        res = self.__return_standard(data,0,[])
        return res
    
    def get_sysvar_id(self,name):
        '''获取指定系统变量的id号'''
        ret = self.get_sysvar_list(name)
        try:
            return (0,ret['id'])
        except:    
            return ret
