import time
import threading
from jaka_requests import *
from config_method import SettingConfig
import AddOns_tool

import platform
if(platform.system()=='Windows'):
    from socketserver import BaseRequestHandler, ThreadingTCPServer
elif(platform.system()=='Linux'):
    from SocketServer import BaseRequestHandler, ThreadingTCPServer

class WeldingMonitor(BaseRequestHandler):
    def handle(self):
        address, pid = self.client_address
        while True:
            try:
                data = self.request.recv(1024)
            except:
                print('close!')
                break
            if len(data) <= 0:
                print('close!')
                break
            if data.decode() == 'welding begin':
                t = threading.Thread(target = self.arc_monitor)
                self.arc_working = True
                t.setDaemon(True)
                t.start()
                self.request.sendall('get'.encode())
            elif data.decode() == 'welding end':
                self.arc_working = False
                self.request.sendall('get'.encode())
            else:
                print(data.decode())
                self.request.sendall('none'.encode())

    def arc_monitor(self):
        pass
        cmd = JAKAREQUESTS('127.0.0.1')
        cmd._JAKAREQUESTS__login_flag = True
        dataConfiger = SettingConfig()
        dataConfiger.get_data()
        arc_success = dataConfiger.address['arcon_success']
        while self.arc_working:
            IOState = cmd.get_io_state(-1)
            if 'RobotIOState' in str(IOState.__class__):
                success_typekey = self.typeKeyGet(arc_success[0],IOState)
                if not (success_typekey.di[arc_success[1]]):
                    cmd.pause_program()
                    break
            time.sleep(0.5)


    def typeKeyGet(self,IOtype,IOState):
        typekey = { 
            0:IOState.cabIOState,
            1:IOState.tioState,#'tioState',
            2:IOState.extIOState,#'extIOState'
            4:IOState.mbSlaveIOState,
            5:IOState.pnDevIOState}

        return typekey[IOtype]


class SingleLock(threading.Thread):
    def __init__(self,configdata=SettingConfig):
        self.dataConfiger = configdata
        threading.Thread.__init__(self)
        self.writetimes = 0

    def run(self):
        errFlag = False
        robotip = AddOns_tool.get_config_info('RobotIP','ip')
        cmd = JAKAREQUESTS(robotip)
        cmd._JAKAREQUESTS__login_flag = True
        while True:
            data = self.dataConfiger.get_data()
            if data != None:
                arcOn = self.dataConfiger.address['arc_on']
                air_supply = self.dataConfiger.address['air_supply']
                robot_ready = self.dataConfiger.address['robot_ready']
                robot_alarm = self.dataConfiger.address['robot_alarm']
                welding_ready = self.dataConfiger.address['welding_ready']

                weld_close_flag = True
                program_close_flag = True
                start_sigal = True
                break
            time.sleep(1)

        while start_sigal:
            if self.writetimes < self.dataConfiger.writetimes:
                arcOn = self.dataConfiger.address['arc_on']
                air_supply = self.dataConfiger.address['air_supply']
                robot_ready = self.dataConfiger.address['robot_ready']
                robot_alarm = self.dataConfiger.address['robot_alarm']
                welding_ready = self.dataConfiger.address['welding_ready']
                self.writetimes += 1

            IOState = cmd.get_io_state(-1)
            if 'RobotIOState' in str(IOState.__class__):
                weld_ready_typekey = self.typeKeyGet(welding_ready[0],IOState)
                if welding_ready[1] != 'null' and welding_ready != -1:
                    try:
                        weld_ready_typekey.di[welding_ready[1]]
                        welding_ready_exist = True
                    except:
                        welding_ready_exist = False
                    if welding_ready_exist:
                        if (weld_ready_typekey.di[welding_ready[1]] and weld_close_flag):
                            cmd.set_dout(arcOn[0],arcOn[1],False)
                            if (air_supply[1] != 'null'):
                                cmd.set_dout(air_supply[0],air_supply[1],False)
                            cmd.pause_program() 
                            print('robot_ready')
                            weld_close_flag = False
                            continue
                        elif not weld_ready_typekey.di[welding_ready[1]] and not weld_close_flag:
                            weld_close_flag = True

                program_state = cmd.get_program_state()
                if program_state != 1 and program_close_flag:
                    cmd.set_dout(arcOn[0],arcOn[1],False)
                    if air_supply[1] != 'null':
                        cmd.set_dout(air_supply[0],air_supply[1],False)
                    cmd.set_dout(robot_alarm[0],robot_alarm[1],True)

                    program_close_flag = False
                    continue
                elif not program_close_flag and program_state == 1:
                    program_close_flag = True
            time.sleep(1)
        
    def typeKeyGet(self,IOtype,IOState):
        typekey = { 
            0:IOState.cabIOState,
            1:IOState.tioState,#'tioState',
            2:IOState.extIOState,#'extIOState'
            4:IOState.mbSlaveIOState,
            5:IOState.pnDevIOState}

        return typekey[IOtype]


if __name__=='__main__':
    server = ThreadingTCPServer(('172.30.0.202',10040),WeldingMonitor)
    print('listening')
    server.serve_forever()