import configparser
from AddOns_tool import get_path
class SettingConfig():
    def __init__(self):
        self.file_path = get_path()[0] + 'weldingSetting.ini'
        self.config = configparser.ConfigParser()
        self.config.read(self.file_path,encoding='utf-8')
        self.context = {}
        self.address = {}
        self.weldingsetting = {}
        self.jobmode = 0
        self.get_data()
        self.init_value()
        self.writetimes = 0

    def writeConfig(self,data):
        for section in data.keys():
            if not (section in self.config.sections()):
                self.config.add_section(section)
                
            for option in data[section].items():
                self.config.set(section,option[0],str(option[1]))
        
        self.config.write(open(self.file_path,'w'))
        self.get_data()
        self.writetimes += 1

    def get_data(self):
        self.config = configparser.ConfigParser()
        self.config.read(self.file_path,encoding='utf-8')
        if self.config.sections ==[]:
            self.context = None
            return None
        else:
            for section in self.config.sections():
                mid = {}
                for option in self.config.options(section):
                    mid[option] = self.config.get(section,option)
                    self.context[section] = mid
            self.init_value()
            return self.context

    def address_change(self,IOname):
        for key in self.context['ioSettingType'].keys():
            x = [str(int(self.context['ioSettingAdress'][key])-1),self.context['ioSettingAdress'][key]][self.context['ioSettingType'][key] == '0']
            self.context['ioSettingAdress'][key] = x
        return 0
    
    def IOaddr(self,ioname):
        data = self.context
        if data != None:
            IO_type = data['ioSettingType']
            IO_addr = data['ioSettingAdress']
            iotype = ioname.lower()
            ioaddr = ioname.lower()
            if IO_addr[ioaddr] != '':
                io = [int(IO_type[iotype]),int(IO_addr[ioaddr])-1]
            else:
                io = [int(IO_type[iotype]),'null']
            return io
        else:
            return None

    def init_value(self):
        for interface in self.context['ioSettingType'].keys():
            self.address[interface] = self.IOaddr(interface)
        for interface in self.context['weldingSetting'].keys():
            self.weldingsetting[interface] = self.context['weldingSetting'][interface]
        self.jobmode = self.context['jobmode']['job_mode']