function dataJson(data) {
    console.log(data);
    var config = data;
    //##Method of getting IP group URL from configuration file##
    //my_robot = "http://" + config.IP + ":" + "10005/robot/v1.0/"
    //my_url = "http://" + config.IP + ":" + config.PORT + "/"

    //##Method of pulling URL from address bar##
    url = window.location.hostname; 
    my_robot = "http://" + url + ":" + "10005/robot/v1.0/";
    my_url = "http://" + url + ":" + config.PORT + "/";

    console.log("myurl:",my_url,"\nmyrobot:",my_robot);

}
/**
 * @description 前端页面输出日志
 * @param {list} mesg 第一位为errcode 0代表日志信息  1代表错误信息
 */
function errlog(mesg)
{
    mesg[0] == 0 ? my_id("errlog").style.color = "#343232" : my_id("errlog").style.color = "#D80C1E"
    my_id("errlog").innerHTML = mesg[1];
}

/**
 * @function Send command to robot 10005 port
 * @param Fuc Instruction name
 * @param body Instruction body, JSON format, empty by default.
 * @return list[errcode,data] errcode:0 suc -12 fail
 * */
 function send_to_robot(Fuc,Body = "")
 {
     var R_data;
     $.ajax
     ({
         url: my_robot + Fuc,
         type:'POST',
         async: false,
         dataType:'json',
         contentType:'application/json;charset=UTF-8',
         data:JSON.stringify(Body),
         success:function(data)
         {
             if (data.error_code != 0) 
             {
                 //console.log("An error occurred(AddOn):" + data.errormsg);
                 R_data = [-12,"An error occurred(AddOn):" + data.errormsg];
             }
             //console.log(JSON.stringify(data.data.ioState.cabIOState.do));
             R_data = [0,data];
         },
         error:function(jqXHR)
         {
             //console.log("An error occurred(AJAX):" + jqXHR.status);
             __msg = "unknown error"
             if (jqXHR.status === 0) { __msg = 'Network Problem'; }
             else if (jqXHR.status == 404) { __msg = 'Requested page not found. [404]'; }
             else if (jqXHR.status == 500) { __msg = 'Internal Server Error [500].'; }
             R_data = [-12,"An error occurred(AJAX):" + __msg];
         }
     });
     return R_data;
 }
/**
* @function Send command to robot 10005 port
* @param Fuc service name
* @param body Instruction body, JSON format, empty by default.。
* @return list[errcode,data] errcode:0 suc -12 fail
* */
function send_to_server(fuc,Body = "")
{
 var S_data;
 $.ajax
 ({
     url: my_url + fuc, 
     type:'POST',
     async: false,
     dataType:'text',
     contentType:'application/json;charset=UTF-8',
     data:JSON.stringify(Body),
     success:function(data)
     {
         //console.log("success:\n",data);
         S_data = [0,data];

     },
     error:function(jqXHR)
     {
         //console.log("An error occurred(AJAX):" + jqXHR.status+ "\nurl:" + my_url);
         __msg = "unknown error"
         if (jqXHR.status === 0) { __msg = 'Network Problem'; }
         else if (jqXHR.status == 404) { __msg = 'Requested page not found. [404]'; }
         else if (jqXHR.status == 500) { __msg = 'Internal Server Error [500].'; }
         S_data = [-12,"An error occurred(AJAX):" + __msg];
     }
 });
 return S_data;
}

//Get element list by tag type
function my_class(cls)
{
    // return document.getElementsByTagName(tag);
    return document.getElementsByClassName(cls);
}
//Get element by ID
function my_id(id)
{
    return document.getElementById(id);
}
//Write configuration parameters
function input_config(data)
{
    //console.log("获取配置参数成功\n",data);
    var server_json = JSON.parse(data);                                 //将数据编码为json

    if (server_json["weldingSetting"]["language"] == "CN"){
        window.location.href="./index.html"   
        
    }
    //将参数写入网页元素
    //console.log("server_json:",server_json);
    var server_sections = Object.keys(server_json);                     //ini中的section列表
    // console.log("server_sections:",server_sections);
    var server_options = Object.values(server_json);                    //ini中的option列表，元素个数为section的个数，每个元素也是一个列表，包含一个section中所有的option
    // console.log("server_options:",server_options);
    for(var i = 0; i<server_options.length; i++)                        
    {
        var server_keys = Object.keys(server_options[i]);               
        // console.log("server_keys:",server_keys);

        var server_values = Object.values(server_options[i]);
        // console.log("server_values:",server_values);

        for(var j = 0; j < server_keys.length; j++)
        {
            var server_name = server_keys[j];
            var server_value = server_values[j];
            //console.log("DOM_name:",server_name,"\n","DOM_value:",server_value);
            var Oinput = document.getElementsByName(server_name);
            for(var k=0; k<Oinput.length; k++)
            {
                // 将对应的值填入页面并检查选择按钮状态
                if(Oinput[k].className == server_sections[i])
                {
                    Oinput[k].value = server_value;
                }
                
                if(Oinput[k].id == "robot_mode")
                {
                    Oinput[k].value == 1 ? Oinput[k].checked = true : Oinput[k].checked = false;
                    Oinput[k].value == 1 ? my_id("lb_robotmode").innerHTML = "Debug mode" : my_id("lb_robotmode").innerHTML = "Normal mode";


                }
                if(Oinput[k].name == "job_mode")
                {
                    Oinput[k].value == 1 ? my_id("JOB").checked = true : my_id("ANA").checked = true;
                }
                if(Oinput[k].id == "wire_mode")
                {
                    Oinput[k].value == 1 ? Oinput[k].checked = true : Oinput[k].checked = false;
                    Oinput[k].value == 1 ? Oinput[k].innerHTML = "Stepping wire" : Oinput[k].innerHTML = "Continuous wire";

                }
                if(Oinput[k].id == "manu_arc")
                {

                    Oinput[k].value == 1 ? Oinput[k].innerHTML = "Arc-off" : Oinput[k].innerHTML = "Acr-on";
                }
                if(Oinput[k].id == "manu_air")
                {
                    Oinput[k].value == 1 ? Oinput[k].innerHTML = "Air stop" : Oinput[k].innerHTML = "Air supply";
                }
            }             
        }             
    }    
}
//控制do
/** 
 * @function 设置机器人do
 * @param index do类型和地址的来源控件name ： str
 * @param value do值 : bool
 * 
**/
function set_do(index,value){ 
    do_type = my_id(index + "_type").value
    do_addr = my_id(index + "_addr").value-1
    Body = {
        "dout": {
        "type": do_type, 
        "index": do_addr,
        "value": value     
        }
        }
        r = send_to_robot("set_dout",Body);    
    return r
}

//获取配置参数并校验
/**
 * 
 * @param {*list} section 需要获取发送的元素class名列表
 * @returns [未补充的内容个数,获取到的json]
 */
 function get_config(section)
 {
     var my_json = {}
     var check_list = 0
     for(var i=0; i<section.length; i++)
     {       
         var my_section = my_class(section[i])
         //console.log(my_section);
         var my_json_temp = {};
         for(var j=0; j<my_section.length; j++ )
         {
             var my_option = my_section[j].name;
             var my_value = my_section[j].value;
             if(my_section[j].className == "ioSettingAdress"){
                 if(my_section[j].value == ""){
                     errlog([1,"Please fill in the"+  my_option  +"on the IO Setting page!!!"]);
                     my_section[j].style.borderColor = "#D80C1E";
                     check_list = check_list + 1
                 }
                 if(my_section[j].value != ""){
                     my_section[j].style.borderColor = "#999999";
                 }                   
             }
             if(my_section[j].className == "weldingSetting"){
                 if(my_id("ANA").checked && my_option != "job_num")
                 {
 
                     if(my_section[j].value == ""){
                         errlog([1,"Please fill in the"+  my_option  +"on the welding parameters page!!!"]);
                         my_section[j].style.borderColor = "#D80C1E";
                         check_list = check_list + 1
                     }
                     if(my_section[j].value != ""){
                         my_section[j].style.borderColor = "#999999";
                     }   
                 }
                 if(my_id("JOB").checked && my_option == "job_num")
                 {
                     if(my_section[j].value == ""){
                         errlog([1,"Please fill in the job number!!!"]);
                         my_section[j].style.borderColor = "#D80C1E";
                         check_list = check_list + 1
                     }
                     if(my_section[j].value != ""){
                         my_section[j].style.borderColor = "#999999";
                     }  
                 }
             
             }
 
             my_json_temp[my_option] = my_value;
             // console.log(my_option,my_value);
         }
         my_json[section[i]] = my_json_temp;
     }
     // console.log(my_json)
     return [check_list,my_json]
 }

//初始化页面
window.onload = function()
{

//初始化 选中page3按钮 隐藏页面1/2
    my_id("page_3").style.color = "#D80C1E";
    my_id("page_3").style.borderBottomStyle = "solid ";
    my_id("page_3").style.borderBottomColor = "#D80C1E";
    my_id("page1").style.display = "none";
    my_id("page2").style.display = "none";
    //从服务器获取配置参数写入
    setTimeout(()=>{
        r = send_to_server("getconfig",{"message":"hello,please give me config"});
        r[0] == -12?  errlog([1,"Failed to read parameters!!!" + r[1]]) : input_config(r[1]);
    },200)

    //模式切换之后赋值
    $('input[type=radio][name=mode]').on("change",function() {
    var Temp = my_id("JOB1").value;
    my_id("JOB1").value = my_id("ANA1").value;
    my_id("ANA1").value = Temp;
    });
    //调试模式文字变换
    $("#robot_mode").click(function() { 
        // alert(this.value);
        if(my_id("robot_mode").value == 0){
            my_id("robot_mode").value = 1;
            my_id("lb_robotmode").innerHTML = "Debug mode";
        }
        else{
            my_id("robot_mode").value = 0;
            my_id("lb_robotmode").innerHTML = "Normal mode";
            
        }

        });
    //走丝模式文字变换
    $("#wire_mode").click(function() { 
        // alert(this.value);
        if(my_id("wire_mode").value == 0){
            my_id("wire_mode").value = 1;
            my_id("lb_wire_mode").innerHTML = "Stepping wire"
        }
        else{
            my_id("wire_mode").value = 0;
            my_id("lb_wire_mode").innerHTML = "Continuous wire"
            
        }

        });
    //送丝按钮
    my_id("wire_feed").onmousedown = function(){
        if(my_id("wire_mode").value == 1)
        {
            r = set_do("wire_feed",true);
            setTimeout(()=>{
                r = set_do("wire_feed",false);
                r[0] == -12?  errlog([1,"Wire feed stop failed!!!" +r[1]]) : errlog([0," "]);

            },500)
        }
        else{
            r = set_do("wire_feed",true);
        }
        r[0] == -12?  errlog([1,"Wire feed failed!!!" + r[1]]) : errlog([0," "]);
    }
    my_id("wire_feed").onmouseup = function(){

        if(my_id("wire_mode").value == 0)
        {
            r = send_to_robot("wire_feed",false);
            r[0] == -12?  errlog([1,"Wire feed stop failed!!!" + r[1]]) : errlog([0," "]);

            // console.log(r)
        }

    }
    //退丝按钮
    my_id("unwinding").onmousedown = function(){
        if(my_id("wire_mode").value == 1)
        {
            r = set_do("unwinding",true);
            setTimeout(()=>{
                r = set_do("unwinding",false);
            r[0] == -12?  errlog([1,"unwinding stop failed!!!" + r[1]]) : errlog([0," "]);
            },500)
        }
        else{
            r = set_do("unwinding",true);
        }
        r[0] == -12?  errlog([1,"unwinding failed!!!" + r[1]]) : errlog([0,""]);

    }
    my_id("unwinding").onmouseup = function(){

        if(my_id("wire_mode").value == 0)
        {
            r = send_to_robot("unwinding",false);
            r[0] == -12?  errlog([1,"unwinding stop failed!!!" + r[1]]) : errlog([0," "]);

            // console.log(r)
        }

    }

    //中英文切换保存
    my_id("cn_html").onclick = function(){
        var language = {"weldingSetting":{"language":"CN"}} 
        r = send_to_server("sendconfig",language)
        r[0] == -12?  errlog([1,"发送配置参数失败!!!" + r[1]]) : errlog([0,"保存配置文件成功"]);
        setTimeout(() => {
            errlog([0," "])
        }, 3000);
    }
    my_id("en_html").onclick = function(){
        var language = {"weldingSetting":{"language":"EN"}} 
        r = send_to_server("sendconfig",language)
        r[0] == -12?  errlog([1,"发送配置参数失败!!!" + r[1]]) : errlog([0,"保存配置文件成功"]);
        setTimeout(() => {
            errlog([0," "])
        }, 3000);
    }

    //起弧送气按钮
    my_id("manu_arc").onclick = function(){
        if(this.value == 0)
        {
            r = set_do("arc",true);
            if(r[0] == -12){
                errlog([1,"Arc-on failed!!!" + r[1]])
            }
            else{
                errlog([0," "]);
                this.innerHTML = "Arc-off";
                this.value = 1;
            }

        }
        else{
            r = set_do("arc",false);
            if(r[0] == -12){
                errlog([1,"Arc-off failed!!!" + r[1]])
            }
            else{
                errlog([0," "]);
                this.innerHTML = "Arc-on"
                this.value = 0;
            }
        }
    }   
    my_id("manu_air").onclick = function(){

        if(this.value == 0)
        {
            r = set_do("air",true);
            if(r[0] == -12){
                errlog([1,"Air supply failed!!!" + r[1]])
            }
            else{
                errlog([0," "]);
                this.innerHTML = "Air stop";
                this.value = 1;
            }
        }
        else{
            r = set_do("air",false);
            if(r[0] == -12){
                errlog([1,"Air stop faild!!!" + r[1]])
            }
            else{
                errlog([0," "]);
                this.innerHTML = "Air supply"
                this.value = 0;
            }
        }

    }

    //提交按钮
    my_id("submit").onclick = function()
    {
        var section = ["ioSettingType","ioSettingAdress","weldingSetting","control_button","jobmode"];
        check_list  = get_config(section);
        if(check_list[0] == 0){
            r = send_to_server("sendconfig",check_list[1])
            r[0] == -12?  errlog([1,"Failed to send configuration parameters!!!" + r[1]]) : errlog([0,"Successfully saved the configuration file"]);
            setTimeout(() => {
                errlog([0," "])
            }, 3000);
        }    
    }

    // 点击按钮效果函数
    var button_list = ["page_1","page_2","page_3"];
    function button_click(button_id)
    {
        for(var i=0; i<button_list.length;i++)
        {

            if(button_list[i] == button_id)
            {
                my_id(button_list[i]).style.color = "#D80C1E";
                my_id(button_list[i]).style.borderBottomStyle = "solid ";
                my_id(button_list[i]).style.borderBottomColor = "#D80C1E";
            }
            else
            {
                // console.log(button_list[i]);
                my_id(button_list[i]).style.color = "#999999";
                my_id(button_list[i]).style.borderBottomStyle = "none";
            }
        }
    }
    // 控制页面tag
    my_id("page_3").onclick = function()
    {
        my_id("page1").style.display = "none";
        my_id("page2").style.display = "none";
        my_id("page3").style.display = "block";
        button_click("page_3");
    }
    // 起灭弧参数tag
    my_id("page_2").onclick = function()
    {
        my_id("page1").style.display = "none";
        my_id("page3").style.display = "none";
        my_id("page2").style.display = "block";
        button_click("page_2");



    }
    // 机器人io设置tag
    my_id("page_1").onclick = function()
    {
        my_id("page2").style.display = "none";
        my_id("page3").style.display = "none";
        my_id("page1").style.display = "block";
        button_click("page_1");

    }
}

window.onunload = function(){ 
    var section = ["control_button"];
    c = get_config(section);
    r = send_to_server("sendconfig",c[1])

};
