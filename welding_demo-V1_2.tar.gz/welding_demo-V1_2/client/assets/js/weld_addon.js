function dataJson(data) {
    console.log(data);
    var config = data;
    //##从配置文件中拿ip组url的方法##
    //my_robot = "http://" + config.IP + ":" + "10005/robot/v1.0/"
    //my_url = "http://" + config.IP + ":" + config.PORT + "/"

    //##从地址栏拉取url的方法##
    url = window.location.hostname; 
    my_robot = "http://" + url + ":" + "10005/robot/v1.0/";
    my_url = "http://" + url + ":" + config.PORT + "/";

    console.log("myurl:",my_url,"\nmyrobot:",my_robot);

}
/**
 * @description 前端页面输出日志
 * @param {list} mesg 第一位为errcode 0代表日志信息  1代表错误信息
 */
function errlog(mesg)
{
    mesg[0] == 0 ? my_id("errlog").style.color = "#343232" : my_id("errlog").style.color = "#D80C1E"
    my_id("errlog").innerHTML = mesg[1];
}

/**
 * @function 向机器人10005端口发送指令
 * @param Fuc 指令名
 * @param body 指令body，json格式，默认空。
 * @return list[errcode,data] errcode:0 成功 -12失败
 * */
 function send_to_robot(Fuc,Body = "")
 {
     var R_data;
     $.ajax
     ({
         url: my_robot + Fuc,
         type:'POST',
         async: false,
         dataType:'json',
         contentType:'application/json;charset=UTF-8',
         data:JSON.stringify(Body),
         success:function(data)
         {
             if (data.error_code != 0) 
             {
                 //console.log("发生错误(AddOn):" + data.errormsg);
                 R_data = [-12,"发生错误(AddOn):" + data.errormsg];
             }
             //console.log(JSON.stringify(data.data.ioState.cabIOState.do));
             R_data = [0,data];
         },
         error:function(jqXHR)
         {
             //console.log("发生错误(AJAX):" + jqXHR.status);
            __msg = "unknown error"
             if (jqXHR.status === 0) { __msg = 'Network Problem'; }
             else if (jqXHR.status == 404) { __msg = 'Requested page not found. [404]'; }
             else if (jqXHR.status == 500) { __msg = 'Internal Server Error [500].'; }
             R_data = [-12,"发生错误(AJAX):" + __msg];
         }
     });
     return R_data;
 }
/**
* @function 向addon服务发送指令
* @param Fuc 服务名
* @param body 指令body，json格式，默认空。
* @return list[errcode,data] errcode:0 成功 -12失败
* */
function send_to_server(fuc,Body = "")
{
 var S_data;
 $.ajax
 ({
     url: my_url + fuc, 
     type:'POST',
     async: false,
     dataType:'text',
     contentType:'application/json;charset=UTF-8',
     data:JSON.stringify(Body),
     success:function(data)
     {
         //console.log("成功:\n",data);
         S_data = [0,data];

     },
     error:function(jqXHR)
     {
         //console.log("发生错误(AJAX):" + jqXHR.status+ "\nurl:" + my_url);
        __msg = "unknown error"
        if (jqXHR.status === 0) { __msg = 'Network Problem'; }
        else if (jqXHR.status == 404) { __msg = 'Requested page not found. [404]'; }
        else if (jqXHR.status == 500) { __msg = 'Internal Server Error [500].'; }
        S_data = [-12,"发生错误(AJAX):" + __msg];
     }
 });
 return S_data;
}

//通过tag类型获取元素列表
function my_class(cls)
{
    // return document.getElementsByTagName(tag);
    return document.getElementsByClassName(cls);
}
//通过id获取元素
function my_id(id)
{
    return document.getElementById(id);
}
//写配置参数
function input_config(data)
{
    //console.log("获取配置参数成功\n",data);
    var server_json = JSON.parse(data);                                 //将数据编码为json
    console.log(server_json["weldingSetting"]["language"])
    if (server_json["weldingSetting"]["language"] == "EN"){
        window.location.href="./index_en.html"   
        
    }
    //将参数写入网页元素
    //console.log("server_json:",server_json);
    var server_sections = Object.keys(server_json);                     //ini中的section列表
    // console.log("server_sections:",server_sections);
    var server_options = Object.values(server_json);                    //ini中的option列表，元素个数为section的个数，每个元素也是一个列表，包含一个section中所有的option
    // console.log("server_options:",server_options);
    for(var i = 0; i<server_options.length; i++)                        
    {
        var server_keys = Object.keys(server_options[i]);               
        // console.log("server_keys:",server_keys);

        var server_values = Object.values(server_options[i]);
        // console.log("server_values:",server_values);

        for(var j = 0; j < server_keys.length; j++)
        {
            var server_name = server_keys[j];
            var server_value = server_values[j];
            //console.log("DOM_name:",server_name,"\n","DOM_value:",server_value);
            var Oinput = document.getElementsByName(server_name);
            for(var k=0; k<Oinput.length; k++)
            {
                // 将对应的值填入页面并检查选择按钮状态
                if(Oinput[k].className == server_sections[i])
                {
                    Oinput[k].value = server_value;
                }
                
                if(Oinput[k].id == "robot_mode")
                {
                    Oinput[k].value == 1 ? Oinput[k].checked = true : Oinput[k].checked = false;
                    Oinput[k].value == 1 ? my_id("lb_robotmode").innerHTML = "调试模式" : my_id("lb_robotmode").innerHTML = "正常模式";

                }
                if(Oinput[k].name == "job_mode")
                {
                    Oinput[k].value == 1 ? my_id("JOB").checked = true : my_id("ANA").checked = true;
                }
                if(Oinput[k].id == "wire_mode")
                {
                    Oinput[k].value == 1 ? Oinput[k].checked = true : Oinput[k].checked = false;
                    Oinput[k].value == 1 ? Oinput[k].innerHTML = "步进走丝" : Oinput[k].innerHTML = "连续走丝";

                }
                if(Oinput[k].id == "manu_arc")
                {

                    Oinput[k].value == 1 ? Oinput[k].innerHTML = "灭弧" : Oinput[k].innerHTML = "起弧";
                }
                if(Oinput[k].id == "manu_air")
                {
                    Oinput[k].value == 1 ? Oinput[k].innerHTML = "关气" : Oinput[k].innerHTML = "送气";
                }
            }             
        }             
    }    
}
//控制do
/** 
 * @function 设置机器人do
 * @param index do类型和地址的来源控件name ： str
 * @param value do值 : bool
 * 
**/
function set_do(index,value){ 
    do_type = my_id(index + "_type").value
    do_addr = my_id(index + "_addr").value - 1
    Body = {
        "dout": {
        "type": do_type, 
        "index": do_addr,
        "value": value     
        }
        }
        r = send_to_robot("set_dout",Body);    
    return r
}

//获取并校验配置参数
/**
 * 
 * @param {*list} section 需要获取发送的元素class名列表
 * @returns [未补充的内容个数,json]
 */
function get_config(section)
{
    var my_json = {}
    var check_list = 0
    for(var i=0; i<section.length; i++)
    {       
        var my_section = my_class(section[i])
        //console.log(my_section);
        var my_json_temp = {};
        for(var j=0; j<my_section.length; j++ )
        {
            var my_option = my_section[j].name;
            var my_value = my_section[j].value;
            if(my_section[j].className == "ioSettingAdress"){
                if(my_section[j].value == ""){
                    errlog([1,"请填写IO设置页面"+  my_option  +"的地址!!!"]);
                    my_section[j].style.borderColor = "#D80C1E";
                    check_list = check_list + 1
                }
                if(my_section[j].value != ""){
                    my_section[j].style.borderColor = "#999999";
                }                   
            }
            if(my_section[j].className == "weldingSetting"){
                if(my_id("ANA").checked && my_option != "job_num")
                {

                    if(my_section[j].value == ""){
                        errlog([1,"请填写焊接参数页面"+  my_option  +"的内容!!!"]);
                        my_section[j].style.borderColor = "#D80C1E";
                        check_list = check_list + 1
                    }
                    if(my_section[j].value != ""){
                        my_section[j].style.borderColor = "#999999";
                    }   
                }
                if(my_id("JOB").checked && my_option == "job_num")
                {
                    if(my_section[j].value == ""){
                        errlog([1,"请填写JOB号!!!"]);
                        my_section[j].style.borderColor = "#D80C1E";
                        check_list = check_list + 1
                    }
                    if(my_section[j].value != ""){
                        my_section[j].style.borderColor = "#999999";
                    }  
                }
            }

            my_json_temp[my_option] = my_value;
            // console.log(my_option,my_value);
        }
        my_json[section[i]] = my_json_temp;
    }
    // console.log(my_json)
    return [check_list,my_json]
}

//初始化页面
window.onload = function()
{

//初始化 选中page3按钮 隐藏页面1/2
    my_id("page_3").style.color = "#D80C1E";
    my_id("page_3").style.borderBottomStyle = "solid ";
    my_id("page_3").style.borderBottomColor = "#D80C1E";
    my_id("page1").style.display = "none";
    my_id("page2").style.display = "none";
    //从服务器获取配置参数写入
    setTimeout(()=>{
        r = send_to_server("getconfig",{"message":"hello,please give me config"});
        r[0] == -12?  errlog([1,"读取配置参数失败!!!" + r[1]]) : input_config(r[1]);
    },200)

    //模式切换之后赋值
    $('input[type=radio][name=mode]').on("change",function() {
    var Temp = my_id("JOB1").value;
    my_id("JOB1").value = my_id("ANA1").value;
    my_id("ANA1").value = Temp;
    });
    //调试模式文字变换
    $("#robot_mode").click(function() { 
        // alert(this.value);
        if(my_id("robot_mode").value == 0){
            my_id("robot_mode").value = 1;
            my_id("lb_robotmode").innerHTML = "调试模式";
        }
        else{
            my_id("robot_mode").value = 0;
            my_id("lb_robotmode").innerHTML = "正常模式";
            
        }

        });
    //走丝模式文字变换
    $("#wire_mode").click(function() { 
        // alert(this.value);
        if(my_id("wire_mode").value == 0){
            my_id("wire_mode").value = 1;
            my_id("lb_wire_mode").innerHTML = "步进走丝"
        }
        else{
            my_id("wire_mode").value = 0;
            my_id("lb_wire_mode").innerHTML = "连续走丝"
            
        }

        });
    //送丝按钮
    my_id("wire_feed").onmousedown = function(){
        if(my_id("wire_mode").value == 1)
        {
            r = set_do("wire_feed",true);
            setTimeout(()=>{
                r = set_do("wire_feed",false);
                r[0] == -12?  errlog([1,"送丝停止失败!!!" +r[1]]) : errlog([0," "]);

            },500)
        }
        else{
            r = set_do("wire_feed",true);
        }
        r[0] == -12?  errlog([1,"送丝失败!!!" + r[1]]) : errlog([0," "]);
    }
    my_id("wire_feed").onmouseup = function(){

        if(my_id("wire_mode").value == 0)
        {
            r = send_to_robot("wire_feed",false);
            r[0] == -12?  errlog([1,"送丝失败!!!" + r[1]]) : errlog([0," "]);

            // console.log(r)
        }

    }
    //中英文切换保存
    my_id("cn_html").onclick = function(){
        var language = {"weldingSetting":{"language":"CN"}} 
        r = send_to_server("sendconfig",language)
        r[0] == -12?  errlog([1,"发送配置参数失败!!!" + r[1]]) : errlog([0,"保存配置文件成功"]);
        setTimeout(() => {
            errlog([0," "])
        }, 3000);
    }
    my_id("en_html").onclick = function(){
        var language = {"weldingSetting":{"language":"EN"}} 
        r = send_to_server("sendconfig",language)
        r[0] == -12?  errlog([1,"发送配置参数失败!!!" + r[1]]) : errlog([0,"保存配置文件成功"]);
        setTimeout(() => {
            errlog([0," "])
        }, 3000);
    }
    //退丝按钮
    my_id("unwinding").onmousedown = function(){
        if(my_id("wire_mode").value == 1)
        {
            r = set_do("unwinding",true);
            setTimeout(()=>{
                r = set_do("unwinding",false);
            r[0] == -12?  errlog([1,"退丝停止失败!!!" + r[1]]) : errlog([0," "]);
            },500)
        }
        else{
            r = set_do("unwinding",true);
        }
        r[0] == -12?  errlog([1,"退丝失败!!!" + r[1]]) : errlog([0,""]);

    }
    my_id("unwinding").onmouseup = function(){

        if(my_id("wire_mode").value == 0)
        {
            r = send_to_robot("unwinding",false);
            r[0] == -12?  errlog([1,"退丝停止失败!!!" + r[1]]) : errlog([0," "]);

            // console.log(r)
        }

    }
    //起弧送气按钮
    my_id("manu_arc").onclick = function(){
        if(this.value == 0)
        {
            r = set_do("arc",true);
            if(r[0] == -12){
                errlog([1,"起弧失败!!!" + r[1]])
            }
            else{
                errlog([0," "]);
                this.innerHTML = "灭弧";
                this.value = 1;
            }

        }
        else{
            r = set_do("arc",false);
            if(r[0] == -12){
                errlog([1,"灭弧失败!!!" + r[1]])
            }
            else{
                errlog([0," "]);
                this.innerHTML = "起弧"
                this.value = 0;
            }
        }
    }   
    my_id("manu_air").onclick = function(){

        if(this.value == 0)
        {
            r = set_do("air",true);
            if(r[0] == -12){
                errlog([1,"送气失败!!!" + r[1]])
            }
            else{
                errlog([0," "]);
                this.innerHTML = "关气";
                this.value = 1;
            }
        }
        else{
            r = set_do("air",false);
            if(r[0] == -12){
                errlog([1,"关气失败!!!" + r[1]])
            }
            else{
                errlog([0," "]);
                this.innerHTML = "送气"
                this.value = 0;
            }
        }

    }

    //提交按钮
    my_id("submit").onclick = function()
    {
        var section = ["ioSettingType","ioSettingAdress","weldingSetting","control_button","jobmode"];
        check_list  = get_config(section);
        if(check_list[0] == 0){
            r = send_to_server("sendconfig",check_list[1])
            r[0] == -12?  errlog([1,"发送配置参数失败!!!" + r[1]]) : errlog([0,"保存配置文件成功"]);
            setTimeout(() => {
                errlog([0," "])
            }, 3000);
        }    
    }

    // 点击按钮效果函数
    var button_list = ["page_1","page_2","page_3"];
    function button_click(button_id)
    {
        for(var i=0; i<button_list.length;i++)
        {

            if(button_list[i] == button_id)
            {
                my_id(button_list[i]).style.color = "#D80C1E";
                my_id(button_list[i]).style.borderBottomStyle = "solid ";
                my_id(button_list[i]).style.borderBottomColor = "#D80C1E";
            }
            else
            {
                // console.log(button_list[i]);
                my_id(button_list[i]).style.color = "#999999";
                my_id(button_list[i]).style.borderBottomStyle = "none";
            }
        }
    }
    // 控制页面tag
    my_id("page_3").onclick = function()
    {
        my_id("page1").style.display = "none";
        my_id("page2").style.display = "none";
        my_id("page3").style.display = "block";
        button_click("page_3");
    }
    // 起灭弧参数tag
    my_id("page_2").onclick = function()
    {
        my_id("page1").style.display = "none";
        my_id("page3").style.display = "none";
        my_id("page2").style.display = "block";
        button_click("page_2");



    }
    // 机器人io设置tag
    my_id("page_1").onclick = function()
    {
        my_id("page2").style.display = "none";
        my_id("page3").style.display = "none";
        my_id("page1").style.display = "block";
        button_click("page_1");

    }
}


window.onunload = function(){ 
    var section = ["control_button"];
    c = get_config(section);
    r = send_to_server("sendconfig",c[1])

};
