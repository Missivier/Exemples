#!/usr/bin/env python3
# -*- coding:utf-8 -*-
import flask
import json 
import time
from flask import request
from AddOns_tool import *
from config_method import SettingConfig
from jaka_requests.JAKAREQUESTS import JAKAREQUESTS
from safty_thread import SingleLock,WeldingMonitor
from threading import Thread
import platform
if(platform.system()=='Windows'):
    from socketserver import BaseRequestHandler, ThreadingTCPServer
elif(platform.system()=='Linux'):
    from SocketServer import BaseRequestHandler, ThreadingTCPServer

dataConfiger = SettingConfig()

server=flask.Flask(__name__)
SocketPort = 20045
PortSysvar = 0

def start_server():
    global SocketPort
    global PortSysvar
    robotip = get_config_info('RobotIP','ip')
    robot = JAKAREQUESTS(robotip)
    robot._JAKAREQUESTS__login_flag = True
    try:
        SOCKETserver = ThreadingTCPServer(('0.0.0.0', SocketPort), WeldingMonitor)
        try:
            SOCKETserver.serve_forever()
        except KeyboardInterrupt:
            server.stop(0)
    except:
        SocketPort += 1
        start_server()

def job_arcon(jobNum):
    jks_txt = ''
    if dataConfiger.jobmode == 'num':
        jobStart = dataConfiger.address['job_mode_start']
        jobEnd = dataConfiger.address['job_mode_end']
        joblen= abs(int(jobEnd[1]) - int(jobStart[1]))
        upper = joblen
        jks_txt = '#digiral set\n'
        move = (int(jobEnd[1])-int(jobStart[1]))/joblen
        while upper >= 0:
            if 2 ** upper <= jobNum:
                jks_txt += 'set_digital_output(%s,%d,1,1)\n'%(jobStart[0],int(jobStart[1])+(move*upper))
                jobNum -= pow(2,upper)
            else:
                jks_txt += 'set_digital_output(%s,%d,0,1)\n'%(jobStart[0],int(jobStart[1])+(move*upper))
            upper -= 1
    else:
        welding_current= dataConfiger.address['welding_current']
        welding_voltage = dataConfiger.address['welding_voltage']
        analogValue = [int(jobNum/10), (jobNum%10)]
        jks_txt += 'set_analog_output(%s,%s,%s,1)\n'%(welding_current[0],welding_current[1],int(analogValue[0])*10)
        jks_txt += 'set_analog_output(%s,%s,%s,1)\n'%(welding_voltage[0],welding_voltage[1],int(analogValue[1])*10)

    return jks_txt
  
def weldSet(weld_parma,paramType):
    jks_txt = ''
    if  paramType == 0:
        welding_current= dataConfiger.address['welding_current']
        welding_voltage = dataConfiger.address['welding_voltage']
        kv = float(dataConfiger.weldingsetting['kv'])
        ki = float(dataConfiger.weldingsetting['ki'])
        bv = float(dataConfiger.weldingsetting['bv'])
        bi = float(dataConfiger.weldingsetting['bi'])
        analogValue = [float(dataConfiger.weldingsetting[weld_parma + '_current']),float(dataConfiger.weldingsetting[weld_parma + '_voltage'])]
        jks_txt += 'set_analog_output(%s,%s,%s,1)#%s_current\n'%(welding_current[0],welding_current[1],(analogValue[0]-bi)/kv,weld_parma)
        jks_txt += 'set_analog_output(%s,%s,%s,1)#%s_voltage\n'%(welding_voltage[0],welding_voltage[1],(analogValue[1]-bv)/ki,weld_parma)

    elif paramType == 1:
        jobNum = int(dataConfiger.weldingsetting['job_num'])
        if dataConfiger.jobmode == 'num':
            jobStart = dataConfiger.address['job_mode_start']
            jobEnd = dataConfiger.address['job_mode_end']
            joblen= abs(int(jobEnd[1]) - int(jobStart[1]))
            upper = joblen
            jks_txt = '#digiral set\n'
            move = (int(jobEnd[1])-int(jobStart[1]))/joblen
            while upper >= 0:
                if 2 ** upper <= jobNum:
                    jks_txt += 'set_digital_output(%s,%d,1,1)\n'%(jobStart[0],int(jobStart[1])+(move*upper))
                    jobNum -= pow(2,upper)
                else:
                    jks_txt += 'set_digital_output(%s,%d,0,1)\n'%(jobStart[0],int(jobStart[1])+(move*upper))
                upper -= 1
        else:
            welding_current= dataConfiger.address['welding_current']
            welding_voltage = dataConfiger.address['welding_voltage']
            analogValue = [int(jobNum/10), (jobNum%10)]
            jks_txt += 'set_analog_output(%s,%s,%s,1)#%s_current\n'%(welding_current[0],welding_current[1],int(analogValue[0])*10,weld_parma)
            jks_txt += 'set_analog_output(%s,%s,%s,1)#%s_voltage\n'%(welding_voltage[0],welding_voltage[1],int(analogValue[1])*10,weld_parma)
        
    return jks_txt

@server.route('/Arc_on',methods=['get'])
def Arc_on():
    print("arc_on")
    params = Params()
    job = params.get()['job']
    if dataConfiger.context == None:
        return  params.message(error= {"error_code":1,"errmsg":'无参数'})
    if dataConfiger.weldingsetting['robot_mode'] == 1:
        jks_txt = 'sleep(1)\n'
    else:
        global PortSysvar
        global SocketPort
        jks_txt = "#arc_on script\n"
        jks_txt += "Monitor_socket = socket_open(\"127.0.0.1\",%s)\n"%SocketPort
        arcOn = dataConfiger.address['arc_on'] 
        air_supply = dataConfiger.address['air_supply']
        robot_ready = dataConfiger.address['robot_ready']
        robot_alarm = dataConfiger.address['robot_alarm']
        arcSuccess = dataConfiger.address['arcon_success']
        if dataConfiger.weldingsetting['ana_mode'] == '1' and dataConfiger.weldingsetting['job_mode'] == '0':
            paramType = 0
            arc_success_wait = dataConfiger.weldingsetting['arc_success_wait']
            air_supply_advance = dataConfiger.weldingsetting['air_supply_advance']
            arc_again_wait = dataConfiger.weldingsetting['arc_again_wait']
            rearc_times = dataConfiger.weldingsetting['rearc_times']
            weld_start = 'arcing'   
            weld_begin = 'welding'
            jks_txt += 'set_digital_output(%s,%s,1,1)#robot_ready\n'%(robot_ready[0],robot_ready[1])
            jks_txt += weldSet(weld_start,paramType)
            jks_txt += 'set_digital_output(%s,%s,1,1)#air_supply\n'%(air_supply[0],air_supply[1])
            jks_txt += 'sleep(%s)#air_supply_advance\n'%air_supply_advance
            jks_txt += 'set_digital_output(%s,%s,1,1)#arcOn\n'%(arcOn[0],arcOn[1])
            jks_txt += 'wait_input(%s,%s,1,%s)#wait arcSuccess\n'%(arcSuccess[0],arcSuccess[1],arc_success_wait)
            jks_txt += 'circletime = 0\n'
            jks_txt += 'while(circletime < %s):\n'%rearc_times
            jks_txt += 'circletime = (circletime+1)\n'
            jks_txt += 'arc_succeed = get_digital_input(%s,%s)\n'%(arcSuccess[0],arcSuccess[1])
            jks_txt += 'if(arc_succeed == 1):\n'
            jks_txt += weldSet(weld_begin,paramType)
            jks_txt += 'break\n'
            jks_txt += 'else:\n'
            jks_txt += 'set_digital_output(%s,%s,0,1)#arcon\n'%(arcOn[0],arcOn[1])
            jks_txt += 'sleep(%s)\n'%arc_again_wait 
            jks_txt += 'set_digital_output(%s,%s,1,1)\n'%(arcOn[0],arcOn[1])
            jks_txt += 'wait_input(%s,%s,1,2)\n'%(arcSuccess[0],arcSuccess[1])
            jks_txt += 'end\n'
            jks_txt += 'end\n'
            jks_txt += 'arc_succeed = get_digital_input(%s,%s)\n'%(arcSuccess[0],arcSuccess[1])
            jks_txt += 'arc_succeed_state = (arc_succeed == 0)\n'
            jks_txt += 'if(arc_succeed_state):\n'
            jks_txt += 'set_digital_output(%s,%s,0,1)\n'%(arcOn[0],arcOn[1])
            jks_txt += 'set_digital_output(%s,%s,0,1)\n'%(air_supply[0],air_supply[1])
            jks_txt += 'set_digital_output(%s,%s,0,1)\n'%(robot_ready[0],robot_ready[1])
            jks_txt += 'set_digital_output(%s,%s,1,1)\n'%(robot_alarm[0],robot_alarm[1])
            jks_txt += 'exit()\n'
            jks_txt += 'end\n'
        else:
            paramType = 1
            weld_start = 'job_num'
            
            jks_txt += 'set_digital_output(%s,%s,1,1)#robot ready\n'%(robot_ready[0],robot_ready[1])
            if job == '':
                jks_txt += weldSet(weld_start,paramType)
            else:
                jks_txt += job_arcon(int(job))
            jks_txt += 'set_digital_output(%s,%s,1,1)#arc on\n'%(arcOn[0],arcOn[1])
            jks_txt += 'wait_input(%s,%s,1,20)\n'%(arcSuccess[0],arcSuccess[1])
            jks_txt += 'arc_succeed = get_digital_input(%s,%s)\n'%(arcSuccess[0],arcSuccess[1])
            jks_txt += 'if (arc_succeed != 1 ):\n'
            jks_txt += 'set_digital_output(%s,%s,0,1)\n'%(arcOn[0],arcOn[1])
            jks_txt += 'set_digital_output(%s,%s,1,1)\n'%(robot_alarm[0],robot_alarm[1])
            jks_txt += 'exit()\n'
            jks_txt += 'end\n'
        jks_txt += "socket_send(Monitor_socket, \"welding begin\")\n"
    return  params.message(jks_str=jks_txt)

@server.route('/Arc_off',methods=['get'])
def Arc_off():
    params = Params()
    if dataConfiger.context == None:
        return  params.message(error={"error_code":1,"errmsg":'无参数'})
    if dataConfiger.weldingsetting['robot_mode'] == '1':
        jks_txt = 'sleep(1)\n'
    else:
        arcOn = dataConfiger.address['arc_on']
        air_supply = dataConfiger.address['air_supply']
        arcSuccess = dataConfiger.address['arcon_success']
        robot_ready = dataConfiger.address['robot_ready']
        jks_txt = '#arc_off script\n'
        jks_txt += "socket_send(Monitor_socket, \"welding end\")\n"
        jks_txt += "socket_close(Monitor_socket)\n"
        if dataConfiger.weldingsetting['ana_mode'] == '1' and dataConfiger.weldingsetting['job_mode'] == '0':
            paramType = 0
            arcoff_setting1 = 'arc_off'
            arcoff_setting2 = 'fill_pit'
            arcoff_setting3 = 'regenerate'
            jks_txt += 'set_digital_output(%s,%s,1,1)\n'%(robot_ready[0],robot_ready[1])
            jks_txt += weldSet(arcoff_setting1,paramType)
            jks_txt += 'sleep(%s)\n'%(dataConfiger.weldingsetting['arc_off_wait'])

            jks_txt += weldSet(arcoff_setting2,paramType)
            jks_txt += 'sleep(%s)\n'%(dataConfiger.weldingsetting['fill_arc_pit'])

            jks_txt += weldSet(arcoff_setting3,paramType)
            jks_txt += 'sleep(%s)\n'%(dataConfiger.weldingsetting['re_firing'])

            jks_txt += 'set_digital_output(%s,%s,0,1)\n'%(arcOn[0],arcOn[1])
            jks_txt += 'set_digital_output(%s,%s,0,1)\n'%(air_supply[0],air_supply[1])
            jks_txt += 'set_digital_output(%s,%s,0,1)\n'%(robot_ready[0],robot_ready[1])
        else:
            paramType = 1
            jks_txt += 'set_digital_output(%s,%s,0,1)\n'%(arcOn[0],arcOn[1])
            jks_txt += 'wait_input(%s,%s,0,0)\n'%(arcSuccess[0],arcSuccess[1])

    return  params.message(jks_str=jks_txt)

@server.route('/Switch',methods=['get'])
def Switch():
    params = Params()
    value1 = params.get("value1").encode('utf-8')
    value2 = params.get("value2").encode('utf-8')
    jks_txt = "#Switch\n"
    welding_current= dataConfiger.address['welding_current']
    welding_voltage = dataConfiger.address['welding_voltage']
    jks_txt += 'set_analog_output(%s,%s,%s,0)\n'%(welding_current[0],welding_current[1],value1)
    jks_txt += 'set_analog_output(%s,%s,%s,0)\n'%(welding_voltage[0],welding_voltage[1],value2)

    return  params.message(jks_txt)

@server.route('/sendconfig',methods=['get','post','options'])
def sendconfig():
    p = Params()
    data= p.get()
    if data == None:
        return p.post_message()
    else:
        dataConfiger.writeConfig(data)
        return p.post_message()

@server.route('/getconfig',methods=['get','post','options'])
def getconfig():
    p = Params()
    data= p.get()
    if data == None:
        return p.post_message()
    else:
        context = dataConfiger.get_data()
        context_txt = json.dumps(context)
        return p.post_message(context_txt)

if __name__ == '__main__':
    portal = get_port()
    safty = SingleLock(dataConfiger)
    safty.setDaemon(True)
    safty.start()
    threadlink = Thread(target = start_server)
    threadlink.setDaemon(True)
    threadlink.start()
    server.config.update(DEBUG=False)
    server.run(host='0.0.0.0',port=portal)
    # server.run(host='127.0.0.1',port=portal)
 