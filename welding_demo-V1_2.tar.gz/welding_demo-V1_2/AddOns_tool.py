# -*- coding:utf-8 -*-
#Ver1.1 6/9
import json
import configparser
import flask

def get_path():
    import sys
    path = sys.path[0]
    char = '/'
    if not '/' in path:
        path = path.replace('/','\\')
        char = '\\'
        addon_name = path.split('\\')[-1]
    else:
        addon_name = path.split('/')[-1]
    file_path = path + char 
    return (file_path,addon_name)

def get_port():
    path = get_path()
    ini_path = path[0] + path[1] + '_config.ini'
    config = configparser.ConfigParser()
    config.read(ini_path)
    port = config.getint('AddOnInfo','portal')
    config = {"PORT": port }
    config = "dataJson(" + str(config) + ")"
    with open(path[0] + "server_config.json","w+") as f :
        f.write(config)
    return port

def get_config_info(section,option):
    path = get_path()
    ini_path = path[0] + path[1] + '_config.ini'
    config = configparser.ConfigParser()
    config.read(ini_path)
    data = config.get(section,option)
    return data

def get_config_option(section):
    path = get_path()
    ini_path = path[0] + path[1] + '_config.ini'
    config = configparser.ConfigParser()
    config.read(ini_path)
    data = config.options(section)
    return data

def write_config_info(section,option,value):
    path = get_path()
    ini_path = path[0] + path[1] + '_config.ini'
    config = configparser.ConfigParser()
    config.read(ini_path)
    config.set(section,option,value)
    config.write(open(ini_path,'w'))


class Params():
    def __init__(self):
        '''根据请求类型建立对象'''
        if flask.request.method == 'GET':
            self.params = flask.request.args
            self.method = 'get'
            
        elif flask.request.method == 'OPTIONS':
            self.method = 'options'
                
        elif flask.request.method == 'POST':
            self.params = flask.request.get_json()
            # self.params = flask.request.get_data()
          
            self.method = 'post'

    def key_exist(self,key):
        '''判断get请求中，是否包含这个键值对'''
        exist = True
        try:
            json.loads(self.params.get(key).encode('utf-8'))["value"]
        except:
            exist = False
        return exist
    
    def get(self,key = -1):
        '''获取指定的键值对，若传入-1，则返回所有键值对'''
        data = None
        if self.method == 'get':
            if key != -1:
                if self.key_exist(key):
                    data = json.loads(self.params.get(key).encode('utf-8'))["value"]
                else:
                    raise ValueError('no this key')
                 
            else:
                data_list = str(self.params).strip('ImmutableMultiDict')[3:-3].split('), (')
                data = {}
                key_name = ''
                for i in data_list:
                    for word in i:
                        if word != ',':
                            key_name += word
                        else:
                            break
                    p = i[len(key_name)+2:]
                    p = p.strip(' ')
                    data[key_name[1:-1]] = json.loads(p[2:-1])['value']
                    key_name = ''
        elif self.method == 'post':
            if key == -1:
                return self.params
            else:
                data = self.params[key]
        return data
    
    def getint(self,key):
        if self.method == 'get':
            data = json.loads(self.params.get(key).encode('utf-8'))["value"]
            if '.' in data:
                return float(data)
            else:
                return int(data)
        elif self.method == 'post':
            return self.get(key)
    
    def type(self,key):
        data = json.loads(self.params.get(key).encode('utf-8'))["type"]
        return data
    
    def calc_lines(self,jks_str):
        if(len(jks_str)>0):
            return jks_str.count("\n")+1
        else:
            return 0
    
    def message(self,jks_str='',beg_str='',end_str='',error = {'error_code':0,'errmsg':''}):
        lines = self.calc_lines(jks_str)
        if beg_str == '' and end_str == '':
            mov_str = {"error_code":0,"jksstr":jks_str,"lines":lines}
        elif beg_str!='' and end_str!='':
            beg_lines = self.calc_lines(beg_str)
            end_lines = self.calc_lines(end_str)
            mov_str = {"error_code":0,"begin_jksstr":beg_str,"begin_lines":beg_lines,"end_jksstr": end_str,"end_lines":end_lines} 
        elif error['error_code'] != 0:
            mov_str = {"error_code":error['error_code'],'errmsg':error['errmsg'],"jksstr":'',"lines":0}
        return json.dumps(mov_str,ensure_ascii=False)
    
    def post_message(self,message={}):
        res = flask.make_response()
        if self.method == 'post':
                res = flask.make_response(message)
        res.headers['Access-Control-Allow-Origin'] = '*'
        res.headers['Access-Control-Allow-Methods'] = 'POST,GET,OPTIONS'
        res.headers['Access-Control-Allow-Headers'] = 'x-requested-with,content-type'
        return res

